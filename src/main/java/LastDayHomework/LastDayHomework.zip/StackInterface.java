package LastDayHomework;

public interface StackInterface {
    public void push(int n);

    public int[] pop();
}
